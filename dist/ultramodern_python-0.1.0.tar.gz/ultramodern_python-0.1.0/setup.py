# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['ultramodern_python']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.28.1,<3.0.0', 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['ultramodern-python = ultramodern_python.main:app']}

setup_kwargs = {
    'name': 'ultramodern-python',
    'version': '0.1.0',
    'description': 'Python package inspired by Hypermodern Python series',
    'long_description': 'Ultramodern Python\n=======\n\nNaming which may not be 100% accurate\n\n\n[![Tests](https://github.com/<your-username>/hypermodern-python/workflows/Tests/badge.svg)](https://github.com/ewurch/ultramodern-python/actions?workflow=Tests)\n',
    'author': 'Eduardo Würch',
    'author_email': 'ewurch@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/ewurch/ultramodern-python.git',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

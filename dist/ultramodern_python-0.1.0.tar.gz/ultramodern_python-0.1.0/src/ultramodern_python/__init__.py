"""The Ultramodern Python Project Template."""
__version__ = "0.1.0"

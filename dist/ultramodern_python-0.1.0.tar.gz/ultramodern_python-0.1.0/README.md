Ultramodern Python
=======

Naming which may not be 100% accurate


[![Tests](https://github.com/<your-username>/hypermodern-python/workflows/Tests/badge.svg)](https://github.com/ewurch/ultramodern-python/actions?workflow=Tests)
